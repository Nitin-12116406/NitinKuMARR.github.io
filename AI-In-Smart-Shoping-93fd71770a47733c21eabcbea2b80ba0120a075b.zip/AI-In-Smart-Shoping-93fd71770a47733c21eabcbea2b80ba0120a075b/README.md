The "AI in Smart Shopping" project aims to enhance the shopping experience for customers by utilizing the power of artificial intelligence technologies. 
The project focuses on the development of a chatbot that can interact with customers in a natural language and provide them with personalized shopping recommendations, product information, and assistance with their purchase decisions.  
It is implemented by using HTML,CSS AND java script , just a basic chatbot
